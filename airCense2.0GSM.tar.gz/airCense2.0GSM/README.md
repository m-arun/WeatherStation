# airCense2.0GSM

Interfacing SIM800C module with STM32F4Discovery development kit.
The STM code pushes the aquired sensor data from various to a HTTP Server(HTTP POST), the sensor data is to aggregated in JSON format.
